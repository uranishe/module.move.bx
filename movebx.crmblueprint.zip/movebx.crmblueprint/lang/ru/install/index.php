<?php

$MESS['MOVEBX_CRM_BLUEPRINT_MODULE_NAME'] = 'MoveBX: Тиражирование CRM Bitrix24';
$MESS['MOVEBX_CRM_BLUEPRINT_MODULE_DESCRIPTION'] = 'Экспорт и импорт CRM-настроек, пользовательских полей, БП, роботов и триггеров через JSON.';
$MESS['MOVEBX_CRM_BLUEPRINT_PARTNER_NAME'] = 'MoveBX';
$MESS['MOVEBX_CRM_BLUEPRINT_PARTNER_URI'] = 'https://example.com';
