<?php

\Bitrix\Main\Loader::registerAutoLoadClasses(
    'movebx.crmblueprint',
    [
        'Movebx\\CrmBlueprint\\Storage\\FileStorage' => 'lib/Storage/FileStorage.php',
        'Movebx\\CrmBlueprint\\Http\\JsonDownloader' => 'lib/Http/JsonDownloader.php',
        'Movebx\\CrmBlueprint\\Service\\BlueprintExporter' => 'lib/Service/BlueprintExporter.php',
        'Movebx\\CrmBlueprint\\Service\\BlueprintImporter' => 'lib/Service/BlueprintImporter.php',
        'Movebx\\CrmBlueprint\\Service\\ModuleFacade' => 'lib/Service/ModuleFacade.php',
    ]
);
